%!PS-Adobe-3.0 EPSF-3.0
%%BoundingBox: -30 -30 30 30 
%%HiResBoundingBox: -29.34645 -29.34645 29.34645 29.34645 
%%Creator: MetaPost 2.00
%%CreationDate: 2021.01.25:1428
%%Pages: 1
%%DocumentResources: procset mpost-minimal
%%DocumentSuppliedResources: procset mpost-minimal
%%EndComments
%%BeginProlog
%%BeginResource: procset mpost-minimal
/bd{bind def}bind def/fshow {exch findfont exch scalefont setfont show}bd
/fcp{findfont dup length dict begin{1 index/FID ne{def}{pop pop}ifelse}forall}bd
/fmc{FontMatrix dup length array copy dup dup}bd/fmd{/FontMatrix exch def}bd
/Amul{4 -1 roll exch mul 1000 div}bd/ExtendFont{fmc 0 get Amul 0 exch put fmd}bd
/ScaleFont{dup fmc 0 get Amul 0 exch put dup dup 3 get Amul 3 exch put fmd}bd
/SlantFont{fmc 2 get dup 0 eq{pop 1}if Amul FontMatrix 0 get mul 2 exch put fmd}bd
%%EndResource
%%EndProlog
%%BeginSetup
%%EndSetup
%%Page: 1 1
 0 0 0 setrgbcolor 0 0.5 dtransform truncate idtransform setlinewidth pop
 [] 0 setdash 1 setlinejoin 10 setmiterlimit
newpath 28.34645 0 moveto
28.34645 7.51828 25.35938 14.72774 20.04356 20.04356 curveto
14.72774 25.35938 7.51828 28.34645 0 28.34645 curveto
-7.51828 28.34645 -14.72774 25.35938 -20.04356 20.04356 curveto
-25.35938 14.72774 -28.34645 7.51828 -28.34645 0 curveto
-28.34645 -7.51828 -25.35938 -14.72774 -20.04356 -20.04356 curveto
-14.72774 -25.35938 -7.51828 -28.34645 0 -28.34645 curveto
7.51828 -28.34645 14.72774 -25.35938 20.04356 -20.04356 curveto
25.35938 -14.72774 28.34645 -7.51828 28.34645 0 curveto closepath stroke
 0 2 dtransform truncate idtransform setlinewidth pop 1 setlinecap
newpath 28.34645 0 moveto
21.34645 0 lineto stroke
 0 0.5 dtransform truncate idtransform setlinewidth pop
newpath 28.19131 2.96228 moveto
25.20775 2.64876 lineto stroke
newpath 27.72679 5.89473 moveto
24.79239 5.27089 lineto stroke
newpath 26.9588 8.75993 moveto
24.10565 7.83282 lineto stroke
newpath 25.89565 11.52916 moveto
23.15501 10.30899 lineto stroke
 0 1.5 dtransform truncate idtransform setlinewidth pop
newpath 24.54887 14.17232 moveto
20.21866 11.67247 lineto stroke
 0 0.5 dtransform truncate idtransform setlinewidth pop
newpath 22.93173 16.66238 moveto
20.50476 14.89894 lineto stroke
newpath 21.06493 18.96735 moveto
18.83553 16.95992 lineto stroke
newpath 18.96735 21.06493 moveto
16.95992 18.83553 lineto stroke
newpath 16.66238 22.93173 moveto
14.89894 20.50476 lineto stroke
 0 1.5 dtransform truncate idtransform setlinewidth pop
newpath 14.17232 24.54887 moveto
11.67247 20.21866 lineto stroke
 0 0.5 dtransform truncate idtransform setlinewidth pop
newpath 11.52916 25.89565 moveto
10.30899 23.15501 lineto stroke
newpath 8.75993 26.9588 moveto
7.83282 24.10565 lineto stroke
newpath 5.89473 27.72679 moveto
5.27089 24.79239 lineto stroke
 0.5 0 dtransform exch truncate exch idtransform pop setlinewidth
newpath 2.96228 28.19131 moveto
2.64876 25.20775 lineto stroke
 2 0 dtransform exch truncate exch idtransform pop setlinewidth
newpath 0 28.34645 moveto
0 21.34645 lineto stroke
 0.5 0 dtransform exch truncate exch idtransform pop setlinewidth
newpath -2.96228 28.19131 moveto
-2.64876 25.20775 lineto stroke
 0 0.5 dtransform truncate idtransform setlinewidth pop
newpath -5.89473 27.72679 moveto
-5.27089 24.79239 lineto stroke
newpath -8.75993 26.9588 moveto
-7.83282 24.10565 lineto stroke
newpath -11.52916 25.89565 moveto
-10.30899 23.15501 lineto stroke
 0 1.5 dtransform truncate idtransform setlinewidth pop
newpath -14.17232 24.54887 moveto
-11.67247 20.21866 lineto stroke
 0 0.5 dtransform truncate idtransform setlinewidth pop
newpath -16.66238 22.93173 moveto
-14.89894 20.50476 lineto stroke
newpath -18.96735 21.06493 moveto
-16.95992 18.83553 lineto stroke
newpath -21.06493 18.96735 moveto
-18.83553 16.95992 lineto stroke
newpath -22.93173 16.66238 moveto
-20.50476 14.89894 lineto stroke
 0 1.5 dtransform truncate idtransform setlinewidth pop
newpath -24.54887 14.17232 moveto
-20.21866 11.67247 lineto stroke
 0 0.5 dtransform truncate idtransform setlinewidth pop
newpath -25.89565 11.52916 moveto
-23.15501 10.30899 lineto stroke
newpath -26.9588 8.75993 moveto
-24.10565 7.83282 lineto stroke
newpath -27.72679 5.89473 moveto
-24.79239 5.27089 lineto stroke
newpath -28.19131 2.96228 moveto
-25.20775 2.64876 lineto stroke
 0 2 dtransform truncate idtransform setlinewidth pop
newpath -28.34645 0 moveto
-21.34645 0 lineto stroke
 0 0.5 dtransform truncate idtransform setlinewidth pop
newpath -28.19131 -2.96228 moveto
-25.20775 -2.64876 lineto stroke
newpath -27.72679 -5.89473 moveto
-24.79239 -5.27089 lineto stroke
newpath -26.9588 -8.75993 moveto
-24.10565 -7.83282 lineto stroke
newpath -25.89565 -11.52916 moveto
-23.15501 -10.30899 lineto stroke
 0 1.5 dtransform truncate idtransform setlinewidth pop
newpath -24.54887 -14.17232 moveto
-20.21866 -11.67247 lineto stroke
 0 0.5 dtransform truncate idtransform setlinewidth pop
newpath -22.93173 -16.66238 moveto
-20.50476 -14.89894 lineto stroke
newpath -21.06493 -18.96735 moveto
-18.83553 -16.95992 lineto stroke
newpath -18.96735 -21.06493 moveto
-16.95992 -18.83553 lineto stroke
newpath -16.66238 -22.93173 moveto
-14.89894 -20.50476 lineto stroke
 0 1.5 dtransform truncate idtransform setlinewidth pop
newpath -14.17232 -24.54887 moveto
-11.67247 -20.21866 lineto stroke
 0 0.5 dtransform truncate idtransform setlinewidth pop
newpath -11.52916 -25.89565 moveto
-10.30899 -23.15501 lineto stroke
newpath -8.75993 -26.9588 moveto
-7.83282 -24.10565 lineto stroke
newpath -5.89473 -27.72679 moveto
-5.27089 -24.79239 lineto stroke
 0.5 0 dtransform exch truncate exch idtransform pop setlinewidth
newpath -2.96228 -28.19131 moveto
-2.64876 -25.20775 lineto stroke
 2 0 dtransform exch truncate exch idtransform pop setlinewidth
newpath 0 -28.34645 moveto
0 -21.34645 lineto stroke
 0.5 0 dtransform exch truncate exch idtransform pop setlinewidth
newpath 2.96228 -28.19131 moveto
2.64876 -25.20775 lineto stroke
 0 0.5 dtransform truncate idtransform setlinewidth pop
newpath 5.89473 -27.72679 moveto
5.27089 -24.79239 lineto stroke
newpath 8.75993 -26.9588 moveto
7.83282 -24.10565 lineto stroke
newpath 11.52916 -25.89565 moveto
10.30899 -23.15501 lineto stroke
 0 1.5 dtransform truncate idtransform setlinewidth pop
newpath 14.17232 -24.54887 moveto
11.67247 -20.21866 lineto stroke
 0 0.5 dtransform truncate idtransform setlinewidth pop
newpath 16.66238 -22.93173 moveto
14.89894 -20.50476 lineto stroke
newpath 18.96735 -21.06493 moveto
16.95992 -18.83553 lineto stroke
newpath 21.06493 -18.96735 moveto
18.83553 -16.95992 lineto stroke
newpath 22.93173 -16.66238 moveto
20.50476 -14.89894 lineto stroke
 0 1.5 dtransform truncate idtransform setlinewidth pop
newpath 24.54887 -14.17232 moveto
20.21866 -11.67247 lineto stroke
 0 0.5 dtransform truncate idtransform setlinewidth pop
newpath 25.89565 -11.52916 moveto
23.15501 -10.30899 lineto stroke
newpath 26.9588 -8.75993 moveto
24.10565 -7.83282 lineto stroke
newpath 27.72679 -5.89473 moveto
24.79239 -5.27089 lineto stroke
newpath 28.19131 -2.96228 moveto
25.20775 -2.64876 lineto stroke
newpath 2 0 moveto
2 0.53046 1.78925 1.03912 1.41418 1.41418 curveto
1.03912 1.78925 0.53046 2 0 2 curveto
-0.53046 2 -1.03912 1.78925 -1.41418 1.41418 curveto
-1.78925 1.03912 -2 0.53046 -2 0 curveto
-2 -0.53046 -1.78925 -1.03912 -1.41418 -1.41418 curveto
-1.03912 -1.78925 -0.53046 -2 0 -2 curveto
0.53046 -2 1.03912 -1.78925 1.41418 -1.41418 curveto
1.78925 -1.03912 2 -0.53046 2 0 curveto closepath fill
 0.4 0 dtransform exch truncate exch idtransform pop setlinewidth
newpath 0 0 moveto
0 -18.34645 lineto stroke
 0 1.25 dtransform truncate idtransform setlinewidth pop
newpath 0 0 moveto
21.34645 0 lineto stroke
 2 0 dtransform exch truncate exch idtransform pop setlinewidth
newpath 0 0 moveto
1.35046 10.25789 lineto stroke
showpage
%%EOF
