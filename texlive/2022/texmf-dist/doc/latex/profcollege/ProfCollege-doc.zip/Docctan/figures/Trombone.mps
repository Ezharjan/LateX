%!PS-Adobe-3.0 EPSF-3.0
%%BoundingBox: -17 0 1 8 
%%HiResBoundingBox: -16.93625 0 0.00021 7.40952 
%%Creator: MetaPost 2.00
%%CreationDate: 2021.01.29:2212
%%Pages: 1
%%BeginProlog
%%EndProlog
%%Page: 1 1
gsave newpath -16.93625 7.40952 moveto
0.00021 7.40952 lineto
0.00021 0 lineto
-16.93625 0 lineto
 closepath clip
 0.5 0.5 0.5 setrgbcolor
newpath -9.505 6.7463 moveto
-3.70476 6.7463 lineto
-2.0277 6.7463 -0.66322 5.38184 -0.66322 3.70476 curveto
-0.66322 2.0277 -2.0277 0.66322 -3.70476 0.66322 curveto
-13.89449 0.66322 lineto
-15.20604 0.66322 -16.27283 1.73 -16.27199 3.04155 curveto
-16.27283 4.35226 -15.20604 5.41905 -13.89449 5.41905 curveto
-3.70476 5.41905 lineto
-2.75955 5.41905 -1.99048 4.64996 -1.99048 3.70476 curveto
-1.99048 2.75955 -2.75955 1.99048 -3.70476 1.99048 curveto
-9.505 1.99048 lineto
-9.505 1.32726 lineto
-3.70476 1.32726 lineto
-2.39403 1.32726 -1.32726 2.3932 -1.32726 3.70476 curveto
-1.32726 5.01549 -2.39403 6.08226 -3.70476 6.08226 curveto
-13.89449 6.08226 lineto
-15.57156 6.08226 -16.93604 4.71861 -16.93604 3.04155 curveto
-16.93604 1.36447 -15.57156 0 -13.89449 0 curveto
-3.70476 0 lineto
-1.66219 0 0 1.66219 0 3.70476 curveto
0 5.74733 -1.66219 7.40952 -3.70476 7.40952 curveto
-9.505 7.40952 lineto
 closepath fill
 0 0 0 setrgbcolor 0 0.5 dtransform truncate idtransform setlinewidth pop
 [] 0 setdash 0 setlinecap 0 setlinejoin 10 setmiterlimit
newpath 2.03198 9.40952 moveto 0 0 rlineto stroke
newpath -18.96802 -2 moveto 0 0 rlineto stroke
grestore
showpage
%%EOF
